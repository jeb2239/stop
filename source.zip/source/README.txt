Compiler for Stop Language
==========================

Compiles to LLVM IR

Attributions:
	Professor Stephen A. Edwards, MicroC Compiler:
		http://www.cs.columbia.edu/~sedwards/
    David Watkins, Dice Compiler:
		http://www.cs.columbia.edu/~sedwards/classes/2015/4115-fall/		
    Jeff Lee, C Language Yacc Grammar:
		https://www.lysator.liu.se/c/ANSI-C-grammar-y.html#translation-unit
